using NodeCanvas.Framework;
using ParadoxNotion.Design;
using UnityEngine;


namespace NodeCanvas.Tasks.Actions {

    public class MoveToButton : ActionTask {

        public BBParameter<Transform> directionTransform;
        public Transform button;
		public float speed;
        public float arrivalDistance;
		public float direction;

        //Use for initialization. This is called only once in the lifetime of the task.
        //Return null if init was successfull. Return an error string otherwise
        protected override string OnInit() {
			
			
			
			return null;
		}

		//This is called once each time the task is enabled.
		//Call EndAction() to mark the action as finished, either in success or failure.
		//EndAction can be called from anywhere.
		protected override void OnExecute() {

       }

		//Called once per frame while the action is active.
		protected override void OnUpdate() {

			//  grabs the Blackboards of the buttons and says which button it's moving to
            Blackboard buttonBlackboard = directionTransform.value.GetComponent<Blackboard>();
            Debug.Log("Now moving to: " + buttonBlackboard.GetVariableValue<string>("movingto"));

			//  the movement part to have the box move to the buttons
            Vector3 arriveAtButton = (button.position - agent.transform.position).normalized;
            agent.transform.position += agent.transform.right * direction * speed * Time.deltaTime;

            float distanceToButton = Vector3.Distance(agent.transform.position, button.transform.position);

			//  if the distance to the button is less than the arrival distance then end the action
            if (distanceToButton < arrivalDistance)
            {
                EndAction(true);
            }
			
        }

		//Called when the task is disabled.
		protected override void OnStop() {
			
		}

		//Called when the task is paused.
		protected override void OnPause() {
			
		}
	}
}